using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assets.Scripts;
using Assets.Scripts.GridSystem;
using Assets.Scripts.Inventory;
using Assets.Scripts.Objects;
using Assets.Scripts.Objects.Entities;
using Assets.Scripts.Objects.Items;
using Assets.Scripts.UI;
using BepInEx;
using HarmonyLib;
using UnityEngine;

namespace stationeerszoopmod
{

    //Original creators: Elmotrix & jixxed
    [BepInPlugin("net.jixxed.stationeers.Zoop", "Zoop Mod", "27.09.2023")]
    [BepInProcess("rocketstation.exe")]
    public class ZoopPatch : BaseUnityPlugin
    {
        public void Log(string line)
        {
            Debug.Log("[Zoop Mod]: " + line);
        }
        
//Originial creators: Elmotrix & jixxed
        private void Awake()
        {
            ZoopPatch.Instance = this;
            this.Log("Hello World");
            try
            {
                var harmony = new Harmony("net.jixxed.stationeers.Zoop");
                harmony.PatchAll();
                this.Log("Patch succeeded");
            }

            catch (Exception e)
            {
                this.Log("Patch Failed");
                this.Log(e.ToString());
            }
        }
        public static ZoopPatch Instance;
    }
}
