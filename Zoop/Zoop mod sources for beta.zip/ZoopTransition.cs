﻿namespace stationeerszoopmod
{
    public enum ZoopTransition
    {
        
        xPyP,
        xPyN,
        xNyP,
        xNyN,
        xPzP,
        xPzN,
        xNzP,
        xNzN,
        yPxP,
        yPxN,
        yNxP,
        yNxN,
        yPzP,
        yPzN,
        yNzP,
        yNzN,
        zPyP,
        zPyN,
        zNyP,
        zNyN,
        zPxP,
        zPxN,
        zNxP,
        zNxN
    }
}