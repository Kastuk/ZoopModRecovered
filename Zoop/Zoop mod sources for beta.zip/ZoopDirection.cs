﻿namespace stationeerszoopmod
{
    public enum ZoopDirection
    {
        x,
        y,
        z
    }
}